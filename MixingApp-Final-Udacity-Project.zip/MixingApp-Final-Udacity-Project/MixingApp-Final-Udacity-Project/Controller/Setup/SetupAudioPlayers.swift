//
//  SetupAudioPlayers.swift
//  MixingApp-Final-Udacity-Project
//
//  Created by Kyle Wilson on 2020-04-21.
//  Copyright © 2020 Xcode Tips. All rights reserved.
//

import Foundation
import AVFoundation

extension TracksViewController {
    
    func setupAudioPlayers() {
        DispatchQueue.global(qos: .background).async {
            for audioPlayer in self.audioPlayers {
                if let audioPlayer = audioPlayer {
                    self.audioEngine.attach(audioPlayer)
                    
                    let equalizer = AVAudioUnitEQ(numberOfBands: 4)
                    
                    self.setupEQ(equalizer: equalizer)
                    
                    self.equalizers.append(equalizer)
                    
                    self.audioEngine.attach(audioPlayer)
                    self.audioEngine.attach(equalizer)
                    
                    self.audioEngine.connect(audioPlayer, to: equalizer, format: nil)
                    self.audioEngine.connect(equalizer, to: self.mixer, format: nil)
                }
            }
        }
    }
    
}
