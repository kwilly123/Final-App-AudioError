//
//  ScheduleAudioFiles.swift
//  MixingApp-Final-Udacity-Project
//
//  Created by Kyle Wilson on 2020-04-21.
//  Copyright © 2020 Xcode Tips. All rights reserved.
//

import Foundation

extension TracksViewController {
    
    func scheduleFilesToStart() {
        DispatchQueue.global(qos: .background).async {
            for (index, audioPlayer) in self.audioPlayers.enumerated() {
                if let file = self.filesArray[index] {
                    audioPlayer?.scheduleFile(file, at: nil, completionHandler: nil)
                    print(file)
                } else {
                    print("Audio File nil")
                }
            }
        }
    }
    
    func scheduleFiles() {
        DispatchQueue.global(qos: .background).async {
            self.audioPlayers[self.index.row]?.scheduleFile((self.filesArray[self.index.row]!), at: nil, completionHandler: nil)
        }
    }
    
}
